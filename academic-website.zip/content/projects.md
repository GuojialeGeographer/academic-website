---
date: "2024-05-19"
design:
  spacing: 5rem
sections:
- block: collection
  content:
    filters:
      folders:
      - project
    text: I enjoy making things. Here are a selection of projects that I have worked
      on over the years.
    title: Selected Projects
  design:
    columns: 3
    fill_image: false
    view: article-grid
title: Projects
type: landing
---
