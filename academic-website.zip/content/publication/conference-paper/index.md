---
abstract: Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis posuere tellus
  ac convallis placerat. Proin tincidunt magna sed ex sollicitudin condimentum. Sed
  ac faucibus dolor, scelerisque sollicitudin nisi. Cras purus urna, suscipit quis
  sapien eu, pulvinar tempor diam. Quisque risus orci, mollis id ante sit amet, gravida
  egestas nisl. Sed ac tempus magna. Proin in dui enim. Donec condimentum, sem id
  dapibus fringilla, tellus enim condimentum arcu, nec volutpat est felis vel metus.
  Vestibulum sit amet erat at nulla eleifend gravida.
author_notes:
- Equal contribution
- Equal contribution
authors:
- admin
- Robert Ford
date: "2013-07-01T00:00:00Z"
doi: ""
featured: true
image:
  caption: 'Image credit: [**Unsplash**](https://unsplash.com/photos/pLCdAaMFLTE)'
  focal_point: ""
  preview_only: false
projects:
- example
publication: In *Hugo Blox Builder Conference*
publication_short: In *ICW*
publication_types:
- paper-conference
publishDate: "2017-01-01T00:00:00Z"
slides: example
summary: Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis posuere tellus
  ac convallis placerat. Proin tincidunt magna sed ex sollicitudin condimentum.
tags:
- Large Language Models
title: An example conference paper
url_code: https://github.com/HugoBlox/hugo-blox-builder
url_dataset: https://github.com/HugoBlox/hugo-blox-builder
url_pdf: ""
url_poster: ""
url_project: ""
url_slides: ""
url_source: https://github.com/HugoBlox/hugo-blox-builder
url_video: https://youtube.com
---

{{% callout note %}}
Click the _Cite_ button above to demo the feature to enable visitors to import publication metadata into their reference management software.
{{% /callout %}}

{{% callout note %}}
Create your slides in Markdown - click the _Slides_ button to check out the example.
{{% /callout %}}

Add the publication's **full text** or **supplementary notes** here. You can use rich formatting such as including [code, math, and images](https://docs.hugoblox.com/content/writing-markdown-latex/).
