---
cascade:
- _target:
    kind: page
  params:
    show_breadcrumb: true
sections:
- block: collection
  content:
    filters:
      folders:
      - teaching
    title: Teaching
  design:
    columns: 2
    view: article-grid
  id: teaching
summary: My courses
title: Teaching
type: landing
---
