---
date: "2023-10-24"
design:
  spacing: 5rem
sections:
- block: resume-experience
  content:
    username: admin
  design:
    date_format: January 2006
    is_education_first: false
- block: resume-skills
  content:
    title: Skills & Hobbies
    username: admin
  design:
    show_skill_percentage: false
- block: resume-awards
  content:
    title: Awards
    username: admin
- block: resume-languages
  content:
    title: Languages
    username: admin
title: Experience
type: landing
---
