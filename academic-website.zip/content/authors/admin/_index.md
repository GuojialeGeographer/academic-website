---
awards:
- awarder: School
  date_end: "2021-07-01"
  date_start: "2017-09-01"
  icon: awards
  summary: |
    Overview:
    - ”Esri” College Students GIS Software Development Competition in China, Third Prize, 2022
    - GIS Skills Competition for College Students in Anhui Province, Second Prize, 2019-2020
    - The 5th China University Geography Science Exhibition Competition, Third Prize, 2019

- awarder: School
  date_end: "2021-07-01"
  date_start: "2017-09-01"
  icon: awards
  summary: |
    Overview:
    - Excellent Graduation Thesis of Chuzhou University (Top 3%), 2021 
    - Excellent Graduates of Ordinary Colleges and Universities in Anhui Province (Top 2%), 2021    
    - National Encouragement Scholarship, Education Department of Anhui Province (Top 3%), 2020
    - Excellent Interns & Internship Works (Top 10%), 2019  
    - Academic Excellence Scholarship (Three consecutive years), 2017-2020
    - Outstanding Student Cadres (Three consecutive years), 2017-2020

  #title: Blockchain Fundamentals
  url: https://www.edx.org/professional-certificate/uc-berkeleyx-blockchain-fundamentals

- awarder: 30DayMapChallenge 
  certificate_url: https://x.com/GISphereGuide/status/1597998764165582850
  date: "2022-11-20"
  icon: map
  summary: |
    The work was selected to be included in the collection of the most praised works displayed by the event organizer
  url: https://30daymapchallenge.com/

education:
- area: MSc in Geoinformatics Engineering
  date_end: ""
  date_start: "2024-09-16"
  institution: Politecnico di Milano
  summary: |
    This major is a joint master's program between the Department of Computer Science and the Department of Civil Engineering of the School of Engineering of Politecnico di Milano.

- area: BSc in Geography
  date_end: "2021-07-01"
  date_start: "2017-09-01"
  institution: School of Geographic Information and Tourism, Chuzhou University
  button:
    text: Read Thesis
    url: https://example.com
  summary: |
    GPA: 84.85/100

    Ranking: 3/60 (2017 - 2018) ; 8/56 (2018 - 2019) ; 1/56 (2019 - 2020) 

first_name: Jiale
highlight_name: true
last_name: Guo
name_pronunciation: Jiale Guo

interests:
  - GeoAI in Social Media Analyst
  - Geographical Information Science
  - Geospatial Data Science

languages:
- name: English
  percent: 75
- name: Chinese
  percent: 100

organizations:
- name: Politecnico di Milano
  url: https://www.geoinformatics.polimi.it/

profiles:
- icon: envelope
  icon_pack: fas
  link: /#contact
- icon: brands/researchgate
  url: https://www.researchgate.net/profile/Jiale-Guo-7
- icon: brands/github
  url: https://github.com/GuojialeGeographer
- icon: brands/instagram
  url: https://www.instagram.com/
- icon: brands/linkedin
  url: https://www.linkedin.com/
- icon: academicons/google-scholar
  url: https://scholar.google.com/
- icon: academicons/orcid
  url: https://orcid.org/

role: MSC Student

skills:
- items:
  - description: ""
    icon: python
    icon_pack: fab
    name: Python
    percent: 80
  - description: ""
    icon: r
    name: R
    percent: 80
  - description: ""
    icon: chart-bar
    name: Geospatial Data Science
    percent: 80
  - description: ""
    icon: ArcGISPro
    name: ArcGIS Pro
    percent: 80
  name: Technical Skills
  
- color: '#eeac02'
  color_border: '#f0bf23'
  items:
  - description: ""
    icon: person-simple-walk
    name: Hiking
    percent: 60
  - description: ""
    icon: badminton
    name: Badminton
    percent: 100
  - description: ""
    icon: camera
    name: Photography
    percent: 80
  name: Hobbies
  
status:
  icon: ☕️
superuser: true
title: 郭家乐

work:
- company_logo: ""
  company_name: Northwest Institute of Eco-Environment and Resources, Chinese Academy of Sciences
  company_url: "http://www.nieer.cas.cn/"
  date_end: "2022-06-10"
  date_start: "2021-10-08"
  position: Research Assistant    
  summary: |- 
    Runoff simulation and prediction in the Qinghai Lake basin based on the SWAT model
    
    Responsibilities include:
    - Simulation and prediction of multi-year variation rules of water resources in the Qinghai Lake Basin basedon the SWAT model.
    - Conduct data analysis and mapping through remote sensing data analysis and interpretation, checking and proofreading spatial attribute data.

- company_logo: ""
  company_name: Industrial Park Surveying and Mapping Geographic Information Technology Co., Ltd.
  company_url: "https://www.dpark.com.cn/"
  date_end: "2024-07-31"
  date_start: "2023-01-01"
  position: Geographic Information Data Engineer & Project Manager
  summary: |
    
    Responsibilities include:
    - Based on high-deinition remote sensing images of Suzhou City, conduct visual interpretation to determine the scope of forests, grasslands, and wetlands, and carry out the segmentation and processing of the identiied patches.
    - Inductive reasoning, analysis, and understanding of natural resource data, such as land use data and remote sensing images, are conducted to design innovative solutions based on practical needs.

---
I am a master's student in Geomatics Engineering at Politecnico di Milano, Italy (Fall 2024~). 
