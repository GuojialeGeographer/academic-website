---
date: "2023-10-26"
external_link: https://github.com/pytorch/pytorch
tags:
- Hugo
- Wowchemy
- Markdown
title: PyTorch
---

PyTorch is a Python package that provides tensor computation (like NumPy) with strong GPU acceleration.

<!--more-->
