---
# An instance of the Accomplishments widget.
# Documentation: https://docs.hugoblox.com/page-builder/
widget: accomplishments

# This file represents a page section.
headless: true

# Order that this section appears on the page.
weight: 40

# Note: `&shy;` is used to add a 'soft' hyphen in a long heading.
title: 'Accomplish&shy;ments'
subtitle: 'Certifications & Awards'

# Date format
#   Refer to https://docs.hugoblox.com/customization/#date-format
date_format: Jan 2006

# Accomplishments.
#   Add/remove as many `item` blocks below as you like.
#   `title`, `organization`, and `date_start` are the required parameters.
#   Leave other parameters empty if not required.
#   Begin multi-line descriptions with YAML's `|2-` multi-line prefix.
item:
  - certificate_url: ''
    date_end: '2022-12-31'
    date_start: '2022-01-01'
    description: 'Third Prize in the Esri College Students GIS Software Development Competition'
    organization: Esri China
    organization_url: https://www.esrichina.com.cn/
    title: GIS Software Development Competition
    url: ''

  - certificate_url: ''
    date_end: '2020-12-31'
    date_start: '2019-09-01'
    description: 'Second Prize in the GIS Skills Competition for College Students in Anhui Province'
    organization: Anhui Province Education Department
    organization_url: ''
    title: GIS Skills Competition
    url: ''

  - certificate_url: ''
    date_end: '2020-12-31'
    date_start: '2020-01-01'
    description: 'Top 3% of students awarded the National Encouragement Scholarship'
    organization: Ministry of Education
    organization_url: ''
    title: National Encouragement Scholarship
    url: ''

design:
  columns: '1'
---
