---
# An instance of the Featurette widget.
# Documentation: https://docs.hugoblox.com/page-builder/
widget: features

# This file represents a page section.
headless: true

# Order that this section appears on the page.
weight: 65

title: Skills
subtitle: Technical & Professional Competencies

# Showcase personal skills or business features.
# Add/remove as many `feature` blocks below as you like.
# For available icons, see: https://docs.hugoblox.com/getting-started/page-builder/#icons
feature:
  - icon: python
    icon_pack: fab
    name: Python
    description: Advanced
    
  - icon: r-project
    icon_pack: fab
    name: R
    description: Advanced
    
  - icon: database
    icon_pack: fas
    name: SQL
    description: Intermediate
    
  - icon: map
    icon_pack: fas
    name: GIS
    description: Expert
    
  - icon: satellite
    icon_pack: fas
    name: Remote Sensing
    description: Advanced
    
  - icon: chart-line
    icon_pack: fas
    name: Statistics
    description: Intermediate
    
  - icon: brain
    icon_pack: fas
    name: Machine Learning
    description: Advanced
    
  - icon: globe
    icon_pack: fas
    name: Web GIS
    description: Intermediate
    
  - icon: code
    icon_pack: fas
    name: Web Development
    description: Basic

# Uncomment to use emoji icons.
#- icon: ":smile:"
#  icon_pack: "emoji"
#  name: "Emojiness"
#  description: "100%"
---
